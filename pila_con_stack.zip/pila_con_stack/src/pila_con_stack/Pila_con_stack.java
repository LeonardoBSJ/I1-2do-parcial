package pila_con_stack;

import java.util.Stack;

public class Pila_con_stack {

    public static void main(String[] args) {
        Stack<DTO> persona = new Stack<DTO>();
        DTO persona_1 = new DTO();
        persona_1.setNombre("Hector Daniel");
        persona_1.setApellidoPaterno("Manzano");
        persona_1.setApellidoMaterno("Paes");
        persona_1.setEdad(19);

        DTO persona_2 = new DTO();
        persona_2.setNombre("Atziry");
        persona_2.setApellidoPaterno("Cardenas");
        persona_2.setApellidoMaterno("Escobedo");
        persona_2.setEdad(19);

        DTO persona_3 = new DTO();
        persona_3.setNombre("Beyda");
        persona_3.setApellidoPaterno("Hernandez");
        persona_3.setApellidoMaterno("Loyola");
        persona_3.setEdad(19);

        DTO persona_4 = new DTO();
        persona_4.setNombre("Cristina");
        persona_4.setApellidoPaterno("Dias");
        persona_4.setApellidoMaterno("Rodriguez");
        persona_4.setEdad(19);

        DTO persona_5 = new DTO();
        persona_5.setNombre("Erick");
        persona_5.setApellidoPaterno("Hernandez");
        persona_5.setApellidoMaterno("Perez");
        persona_5.setEdad(19);

        persona.push(persona_1);
        persona.push(persona_2);
        persona.push(persona_3);
        persona.push(persona_4);
        persona.push(persona_5);

        System.out.println("Los datos de los amigos");

        for (DTO person : persona) {
            System.out.println(person.toString());

        }
        System.out.println("");
        try {
            Thread.sleep(700);
        } catch (Exception e) {

        }
        for (DTO ultimoamigo : persona) {
            if (ultimoamigo == persona.peek()) {
                System.out.println("los ultimos datos son:");
                System.out.println(ultimoamigo.toString());
            } else {

            }

        }
        DTO eliminado = persona.pop();
        System.out.println("");
        try {
            Thread.sleep(700);
        } catch (Exception e) {

        }
        System.out.println("los datos que se van a eliminar son:" + eliminado);
        System.out.println("");
        try {
            Thread.sleep(700);
        } catch (Exception e) {

        }
        System.out.println("los nuevos datos son:");
        for (DTO actualizada : persona) {
            System.out.println(actualizada.toString());
        }

    }
}
