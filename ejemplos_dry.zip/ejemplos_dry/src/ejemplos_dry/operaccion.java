
package ejemplos_dry;

public class operaccion {
    
    public static int sumar(int A[]) {
        int l = 0;
        for (int i : A) {

            l += i;
        }
        return l;
    }

    public static void encontrar(int A[]) {
        int minimo = Integer.MAX_VALUE;
        int maximo = Integer.MIN_VALUE;
        for (int i : A) {
            if (i < minimo) {

                minimo = i;

            } else if (i > maximo) {
                maximo = i;

            }

        }
        System.out.println("maximo es:" + maximo);
        System.out.println("minimo es:" + minimo);

    } 
}
