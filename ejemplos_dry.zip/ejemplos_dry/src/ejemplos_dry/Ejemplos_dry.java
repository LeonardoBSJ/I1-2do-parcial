package ejemplos_dry;

import static ejemplos_dry.operaccion.encontrar;
import static ejemplos_dry.operaccion.sumar;
import java.util.Scanner;

public class Ejemplos_dry {

    public static void main(String[] args) {
        
    
        Scanner leer = new Scanner(System.in);
        System.out.println("ingrese tamaño del arreglo");
        int jop = leer.nextInt();
        System.out.println("");
        int A[] = new int[jop];
        int j = 0;
        for (int i : A) {
            System.out.println("ingrese el valor de " + (j + 1) + " ");
            A[j] = leer.nextInt();
            j++;
        }
       
        System.out.println("");
        for (int i : A) {
            System.out.print(" [" + i + "]");
        }
        System.out.println("");
        int suma = sumar(A);
        System.out.println("suma es:" + suma);
        System.out.println("");
        encontrar(A);
    }

}


